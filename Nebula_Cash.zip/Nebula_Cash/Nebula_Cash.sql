-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2023 at 01:26 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `surgaki`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `stok_update` ()   BEGIN
    UPDATE db_barang
    JOIN (
        SELECT kode_barang, SUM(jumlah_barang) as total
        FROM db_keranjang
        GROUP BY kode_barang
    ) keranjang
    ON db_barang.kode_barang = keranjang.kode_barang
    SET db_barang.stok = db_barang.stok - keranjang.total;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `total_harga_dashboard` ()   BEGIN
SELECT 
SUM(db_riwayat.harga_barang*db_riwayat.jumlah_barang) AS total_harga
FROM db_riwayat;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `total_harga_transaksi` ()   BEGIN
SELECT 
SUM(db_keranjang.harga_barang*db_keranjang.jumlah_barang) AS total_harga
FROM db_keranjang;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ab_admin`
--

CREATE TABLE `ab_admin` (
  `nama_admin` varchar(100) NOT NULL,
  `username_admin` varchar(30) NOT NULL,
  `password_admin` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ab_admin`
--

INSERT INTO `ab_admin` (`nama_admin`, `username_admin`, `password_admin`) VALUES
('Sarwan Hamid', 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `db_barang`
--

CREATE TABLE `db_barang` (
  `kode_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `tanggal_masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `db_barang`
--

INSERT INTO `db_barang` (`kode_barang`, `nama_barang`, `harga`, `stok`, `tanggal_masuk`) VALUES
(1001, 'Pensil', 2500, 5, '2023-07-06'),
(1002, 'Buku', 5000, 10, '2023-07-06'),
(1003, 'Penghapus', 4000, 6, '2023-07-07'),
(1005, 'Hardisk', 50000, 2, '2023-07-07');

-- --------------------------------------------------------

--
-- Table structure for table `db_keranjang`
--

CREATE TABLE `db_keranjang` (
  `id_transaksi` int(11) NOT NULL,
  `kode_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `tanggal_transaksi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `db_keranjang`
--

INSERT INTO `db_keranjang` (`id_transaksi`, `kode_barang`, `nama_barang`, `harga_barang`, `jumlah_barang`, `total_harga`, `tanggal_transaksi`) VALUES
(1, 1001, 'Pensil', 2500, 10, 25000, '2023-07-07'),
(2, 1005, 'Hardisk', 50000, 1, 50000, '2023-07-07');

-- --------------------------------------------------------

--
-- Table structure for table `db_petugas`
--

CREATE TABLE `db_petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(100) NOT NULL,
  `username_petugas` varchar(30) NOT NULL,
  `password_petugas` varchar(30) NOT NULL,
  `gender_petugas` varchar(50) NOT NULL,
  `tanggaldaftar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `db_petugas`
--

INSERT INTO `db_petugas` (`id_petugas`, `nama_petugas`, `username_petugas`, `password_petugas`, `gender_petugas`, `tanggaldaftar`) VALUES
(1, 'Sarwan Hamid', 'sarwan', '12345', 'Laki-Laki', '2023-07-06');

-- --------------------------------------------------------

--
-- Table structure for table `db_riwayat`
--

CREATE TABLE `db_riwayat` (
  `id_transaksi` int(11) NOT NULL,
  `kode_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `tanggal_transaksi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `db_riwayat`
--

INSERT INTO `db_riwayat` (`id_transaksi`, `kode_barang`, `nama_barang`, `harga_barang`, `jumlah_barang`, `total_harga`, `tanggal_transaksi`) VALUES
(1, 1001, 'Pensil', 2500, 10, 25000, '2023-07-07'),
(2, 1005, 'Hardisk', 50000, 1, 50000, '2023-07-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ab_admin`
--
ALTER TABLE `ab_admin`
  ADD UNIQUE KEY `username_admin` (`username_admin`);

--
-- Indexes for table `db_barang`
--
ALTER TABLE `db_barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indexes for table `db_keranjang`
--
ALTER TABLE `db_keranjang`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `kode_barang` (`kode_barang`);

--
-- Indexes for table `db_petugas`
--
ALTER TABLE `db_petugas`
  ADD PRIMARY KEY (`id_petugas`),
  ADD UNIQUE KEY `username_petugas` (`username_petugas`);

--
-- Indexes for table `db_riwayat`
--
ALTER TABLE `db_riwayat`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `kode_barang` (`kode_barang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db_barang`
--
ALTER TABLE `db_barang`
  MODIFY `kode_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1006;

--
-- AUTO_INCREMENT for table `db_keranjang`
--
ALTER TABLE `db_keranjang`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_petugas`
--
ALTER TABLE `db_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `db_riwayat`
--
ALTER TABLE `db_riwayat`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `db_keranjang`
--
ALTER TABLE `db_keranjang`
  ADD CONSTRAINT `db_keranjang_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `db_barang` (`kode_barang`);

--
-- Constraints for table `db_riwayat`
--
ALTER TABLE `db_riwayat`
  ADD CONSTRAINT `db_riwayat_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `db_barang` (`kode_barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
