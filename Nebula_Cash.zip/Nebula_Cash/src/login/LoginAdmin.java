/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package login;

import admin.AdminDashboard;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Abror
 */
public class LoginAdmin extends javax.swing.JFrame {
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi k = new koneksi();
    
    public LoginAdmin() {
        initComponents();
        k.connect();
    }
    
    class Admin{
        String nama_admin, username_admin, password_admin;
        
        public Admin(){
            this.nama_admin = "";
            this.username_admin = isiUsername.getText();
            this.password_admin = isiPassword.getText();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        isiUsername = new javax.swing.JTextField();
        isiPassword = new javax.swing.JPasswordField();
        TombolMasuk = new javax.swing.JButton();
        TombolShow = new javax.swing.JButton();
        TombolBack = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(isiUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 290, 350, 50));
        getContentPane().add(isiPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, 290, 50));

        TombolMasuk.setBorder(null);
        TombolMasuk.setContentAreaFilled(false);
        TombolMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolMasukActionPerformed(evt);
            }
        });
        getContentPane().add(TombolMasuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 500, 340, 40));

        TombolShow.setBorder(null);
        TombolShow.setContentAreaFilled(false);
        TombolShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolShowActionPerformed(evt);
            }
        });
        getContentPane().add(TombolShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 400, 30, 40));

        TombolBack.setBorder(null);
        TombolBack.setContentAreaFilled(false);
        TombolBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolBackActionPerformed(evt);
            }
        });
        getContentPane().add(TombolBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 50, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LoginAdmin.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void TombolBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolBackActionPerformed
    new HalamanPeran().setVisible(true);
    this.setVisible(false);
    }//GEN-LAST:event_TombolBackActionPerformed

    private void TombolMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolMasukActionPerformed
   Admin u = new Admin();
    try {
        if (u.username_admin.equals("admin") && u.password_admin.equals("admin")) {
            // Jika username dan password adalah "admin admin", maka langsung masuk
            new AdminDashboard().setVisible(true);
            this.setVisible(false);
        } else {
            // Jika bukan "admin admin", lakukan pemeriksaan di database
            this.stat = k.getCon().prepareStatement("SELECT * FROM ab_admin WHERE username_admin = ? AND password_admin = ?");
            this.stat.setString(1, u.username_admin);
            this.stat.setString(2, u.password_admin);
            this.rs = this.stat.executeQuery();
            
            if (!rs.next()) {
                // Jika username tidak ditemukan
                JOptionPane.showMessageDialog(null, "Username tidak ditemukan, silakan periksa kembali.");
            } else {
                // Periksa apakah password cocok
                String passwordDB = rs.getString("password_admin");
                if (!passwordDB.equals(u.password_admin)) {
                    JOptionPane.showMessageDialog(null, "Password salah, silakan coba lagi.");
                } else {
                    // Login berhasil
                    new AdminDashboard().setVisible(true);
                    this.setVisible(false);
                }
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
    }//GEN-LAST:event_TombolMasukActionPerformed

    private void TombolShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolShowActionPerformed
        if (isiPassword.echoCharIsSet()) {
            isiPassword.setEchoChar((char)0);
        } else {
            isiPassword.setEchoChar('*');
        }
    }//GEN-LAST:event_TombolShowActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton TombolBack;
    private javax.swing.JButton TombolMasuk;
    private javax.swing.JButton TombolShow;
    private javax.swing.JPasswordField isiPassword;
    private javax.swing.JTextField isiUsername;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
