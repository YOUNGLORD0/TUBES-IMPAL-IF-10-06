/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package login;

import petugas.PetugasDashboard;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Abror
 */
public class LoginPetugas extends javax.swing.JFrame {
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi k = new koneksi();

    public LoginPetugas() {
        initComponents();
        k.connect();
    }
    
    class Petugas{
        int id_petugas;
        String nama_petugas, username_petugas, password_petugas;
        
        public Petugas(){
            this.id_petugas = 0;
            this.nama_petugas = "";
            this.username_petugas = isiUsername.getText();
            this.password_petugas = isiPassword.getText();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TombolBack = new javax.swing.JButton();
        isiUsername = new javax.swing.JTextField();
        isiPassword = new javax.swing.JPasswordField();
        TombolShow = new javax.swing.JButton();
        TombolMasuk = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TombolBack.setBorder(null);
        TombolBack.setContentAreaFilled(false);
        TombolBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolBackActionPerformed(evt);
            }
        });
        getContentPane().add(TombolBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 50, 30));
        getContentPane().add(isiUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 290, 350, 60));

        isiPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isiPasswordActionPerformed(evt);
            }
        });
        getContentPane().add(isiPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, 290, 50));

        TombolShow.setBorder(null);
        TombolShow.setContentAreaFilled(false);
        TombolShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolShowActionPerformed(evt);
            }
        });
        getContentPane().add(TombolShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 400, 50, 40));

        TombolMasuk.setBorder(null);
        TombolMasuk.setContentAreaFilled(false);
        TombolMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolMasukActionPerformed(evt);
            }
        });
        getContentPane().add(TombolMasuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 500, 340, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LoginPetugas.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void TombolBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolBackActionPerformed
    new HalamanPeran().setVisible(true);
    this.setVisible(false);
    }//GEN-LAST:event_TombolBackActionPerformed

    private void TombolMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolMasukActionPerformed
       Petugas u = new Petugas();
        try {
            this.stat = k.getCon().prepareStatement("SELECT * FROM db_petugas WHERE username_petugas = '" + u.username_petugas + "' AND password_petugas = '" + u.password_petugas + "'");
            this.rs = this.stat.executeQuery();
            
            if(!rs.next()){
                JOptionPane.showMessageDialog(null, "Daftar Dulu masseh!");
            } else {
                new PetugasDashboard().setVisible(true);
                this.setVisible(false);
        }
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_TombolMasukActionPerformed

    private void TombolShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolShowActionPerformed
        if (isiPassword.echoCharIsSet()) {
            isiPassword.setEchoChar((char)0);
        } else {
            isiPassword.setEchoChar('*');
        }
    }//GEN-LAST:event_TombolShowActionPerformed

    private void isiPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isiPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isiPasswordActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPetugas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton TombolBack;
    private javax.swing.JButton TombolMasuk;
    private javax.swing.JButton TombolShow;
    private javax.swing.JPasswordField isiPassword;
    private javax.swing.JTextField isiUsername;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
